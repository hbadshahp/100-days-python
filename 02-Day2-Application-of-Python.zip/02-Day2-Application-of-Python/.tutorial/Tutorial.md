# Day 2 - My Python Success Story
# Why I love python (And you will too...)
Welcome to Day 2 of 100 days of code. Let me start with a story! 
Back in my college, I used to learn C and C++ programming in depth, used to score good marks. I created a bunch of printing, conditionals and loop program. Now what? I wanted to benefit from the same
In my second year of college, I started working (I mean actually working in the industry) with the python programming language. I was not so good with it but I used to write code for a singaporean client and actually make good money without having to actually master Python. Harry then got curious and started working on his Python skills even more.
I then got into web scraping and trust me I made some good easy money on Fiverr just by writing some python programs and charging on per webpage basis to my clients ( I used to automate scraping)

I then learnt flask and got to work with Flask with a university professor abroad. Long story short, Python made a huge impact in my career.

## What can Python do for you?

I want to show you some python programs I created which will surely inspire you to create your own versions of the same as we progress through this tutorial. 
Do not try to recreate them just yet if you are a beginner and just started working on Python. We will make progress gradually trust me

## [Next Lesson>>](https://replit.com/@codewithharry/03-Day3-Modules-and-Pip#main.py)